function add(){
    var b = []
    var c = document.getElementById('fname').value
    var d = document.getElementById('lname').value
    var e = document.getElementById('country').value
    var f = document.getElementById('subject').value
    b.push(c)
    b.push(d)
    b.push(e)
    b.push(f)
    localStorage.setItem("First_name", JSON.stringify(b[0]));
    localStorage.setItem("Last_name", JSON.stringify(b[1]));
    localStorage.setItem("Country", JSON.stringify(b[2]));
    localStorage.setItem("Subject", JSON.stringify(b[2]));
    display()   
}

function display(){
    let new_blog;
    const con = document.getElementById("m")
    var result = JSON.parse(localStorage.getItem("First_name"));
    var result2 = JSON.parse(localStorage.getItem("Last_name"));
    var result3 = JSON.parse(localStorage.getItem("Country"));
    var result4 = JSON.parse(localStorage.getItem("Subject"));
    if ( result ==' ' || result !=null){
        new_blog = `<div class='text center bg-success'><h4>First name is ${result}</h4><p>Lastnameis ${result2}</p><h4>country is ${result3} </h4> <h4>complaint is ${result4}</h4>`
        con.innerHTML += new_blog
        
    }
    else{
        const myform = document.getElementById("form_id")
        myform.addEventListener("display",(e)=>{e.preventDefault();});
    }   
}